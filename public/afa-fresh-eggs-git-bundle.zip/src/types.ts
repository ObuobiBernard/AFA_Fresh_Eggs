export type Role = 'ceo' | 'data_entry' | 'attendant' | 'driver' | 'pending';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: Role;
  shop: string;
  active: boolean;
}

export interface PriceItem {
  id: string;
  farm: string;
  item: string;
  buy: number;
  sell: number;
}

export interface CollectionItem {
  id: string;
  date: string;
  pid: string;
  lbl: string;
  qty: number;
  buy: number;
  shop: string;
  paid_amt: number;
  created_by?: string;
}

export interface SaleItem {
  id: string;
  date: string;
  pid: string;
  lbl: string;
  qty: number;
  price: number;
  shop: string;
  cust_id: string | null;
  paid: number;
  method: string;
  due: string;
  created_by?: string;
}

export interface PaymentItem {
  id: string;
  date: string;
  cust_id: string;
  amt: number;
}

export interface CostItem {
  id: string;
  date: string;
  descr: string;
  amt: number;
  created_by?: string;
}

export interface CustomerItem {
  id: string;
  name: string;
  phone: string;
}

export interface MemberProfile {
  id: string;
  email?: string;
  name?: string;
  phone?: string;
  role: Role;
  shop?: string | null;
  active: boolean;
  created_at?: string;
}

export interface AppStateData {
  prices: PriceItem[];
  col: CollectionItem[];
  sales: SaleItem[];
  pay: PaymentItem[];
  costs: CostItem[];
  customers: CustomerItem[];
  profiles: MemberProfile[];
}

export type TableKey = 'prices' | 'col' | 'sales' | 'pay' | 'costs' | 'customers';

export type TabKey = 'home' | 'collect' | 'sell' | 'credit' | 'costs' | 'prices' | 'team';
